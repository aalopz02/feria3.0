import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ClientService } from '../../services/client.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.css'],
})
export class RegisterPage implements OnInit {

  clientForm: FormGroup;

  constructor(private formB: FormBuilder, private clientService: ClientService) { 
      this.clientForm = this.formB.group({
          id: [''],
          name: [''],
          lastname1: [''],
          lastname2: [''],
          provincia: [''],
          canton: [''],
          distrito: [''],
          birthday: [''],
          phoneNumber: [''],
          username: [''],
          password: ['']
      })
  }

  ngOnInit() {
  }
  
  onSubmit(formValue: any) {

    console.log(formValue.name);
    const id = formValue.id;
    const info = formValue.name + "-" + formValue.lastname1 + "-" + formValue.lastname2 + "-" + formValue.provincia +"-" + formValue.canton + "-" + formValue.distrito + "-" + formValue.birthday 
    + "-" + formValue.phoneNumber + "-" + formValue.username + "-" + formValue.password;
    
    this.clientService.addClient(id, info);

  }
  

}
