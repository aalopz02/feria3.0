import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ClientService } from '../../services/client.service';
import { UpServiceService } from '../../services/up-service.service';
import { LoginService } from './../../services/login.service';
@Component({
  selector: 'app-update',
  templateUrl: './update.page.html',
  styleUrls: ['./update.page.scss'],
})
export class UpdatePage implements OnInit {

  clientForm: FormGroup;
  constructor(private formB: FormBuilder, private clientService: ClientService, private upService: UpServiceService, private login:LoginService) {
    this.clientForm = this.formB.group({
      id: [''],
      name: [''],
      lastname1: [''],
      lastname2: [''],
      provincia: [''],
      canton: [''],
      distrito: [''],
      birthday: [''],
      phoneNumber: [''],
      username: [''],
      password: ['']
  })

   }

  ngOnInit() {
   
    
    this.upService.bringClient(this.login.UserValue).subscribe(data =>{
      console.log(data);

      this.clientForm.setValue(
        {
  
          id: [data.cedula],
          name: [data.nombre],
          lastname1: [data.apellido1],
          lastname2: [data.apellido2],
          provincia: [data.direccion[0]],
          canton: [data.direccion[1]],
          distrito: [data.direccion[2]],
          birthday: [data.fechaNacimiento],
          phoneNumber: [data.telefono],
          username: [this.login.UserValue],
          password: ['']
       })
      
    });

  }
  
  onSubmit(formValue: any) {

    console.log(formValue.name);
    const id = formValue.id;
    const info = formValue.name + "-" + formValue.lastname1 + "-" + formValue.lastname2 + "-" + formValue.provincia +"-" + formValue.canton + "-" + formValue.distrito + "-" + formValue.birthday 
    + "-" + formValue.phoneNumber + "-" + formValue.username + "-" + formValue.password;
    
    this.upService.updateClient(id, info);

  }

}
