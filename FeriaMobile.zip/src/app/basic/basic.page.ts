import { Component, OnInit } from '@angular/core';
import { DelServiceService } from './../services/del-service.service';
import { LoginService } from './../services/login.service';

@Component({
  selector: 'app-basic',
  templateUrl: './basic.page.html',
  styleUrls: ['./basic.page.css'],
})
export class BasicPage implements OnInit {

  constructor(private delService: DelServiceService, private login:LoginService) { }

  ngOnInit() {
  }

  delete(formValue: any) {
    console.log(this.login.UserValue);
    
    this.delService.deleteClient(this.login.UserValue);

  }

}
