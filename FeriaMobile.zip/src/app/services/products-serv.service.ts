import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpParams, HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductsServService {

  constructor(private http: HttpClient, private router:Router) { }

  
  bringProducts(cedula:string): Observable<any>{
   
    const Base_url = 'https://localhost:44303/api/Productor?';

    const params = new HttpParams()
      .set('cedula', cedula);

    console.log(Base_url + params.toString());

    return this.http.get(Base_url + params.toString()).pipe(map((response: any) => response)
    
    );
}

}
