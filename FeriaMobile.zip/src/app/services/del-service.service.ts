import { Injectable } from '@angular/core';
import { HttpParams, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class DelServiceService {

  constructor(private http: HttpClient, private router:Router) { }

  deleteClient(user:string){
    

    const Base_url = 'https://localhost:44303/api/Cliente?';

    const params = new HttpParams()
      .set('user', user)

    
    console.log(Base_url + params.toString());
    
    this.http.delete(Base_url + params.toString()).subscribe(data => {
      console.log(data);
     
        this.router.navigate(["/home"]);
      
    });

   

  }
}

