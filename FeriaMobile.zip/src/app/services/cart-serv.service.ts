import { Injectable } from '@angular/core';
import { HttpParams, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { AlertController } from '@ionic/angular';


@Injectable({
  providedIn: 'root'
})
export class CartServService {

  constructor(private http: HttpClient, private router:Router,public alertController: AlertController) { }


  addToCart(user:string,nombreProducto:string,cantidad:string,cedulaProductor:string){
    const Base_url = 'https://localhost:44303/api/Cart?';
    

    const params = new HttpParams()
    .set('user', user)
    .set('nombreProducto', nombreProducto)
    .set('cantidad', cantidad)
    .set('cedulaProductor', cedulaProductor);

    console.log(Base_url + params.toString());
    
    this.http.put(Base_url + params.toString(), null).subscribe(data => {
      console.log(data);
    });

  }

  bringCart(user:string): Observable<any>{
   
    const Base_url = 'https://localhost:44303/api/Cart?';

    const params = new HttpParams()
      .set('nombreUser', user)
     
    console.log(Base_url + params.toString());

    return this.http.get(Base_url + params.toString()).pipe(map((response: any) => response)
    
    );


    
  }


  deleteCart(user:string, nombreProducto:string,cedulaProductor:string){
    

    const Base_url = 'https://localhost:44303/api/Cart?';

    const params = new HttpParams()
      .set('user', user)
      .set('nombreProducto', nombreProducto)
      .set('cedulaProductor', cedulaProductor);

    
    console.log(Base_url + params.toString());
    
    this.http.delete(Base_url + params.toString()).subscribe(data => {
      console.log(data);
     
      
    });

   

  }

  buy(user:string,factura:string){
    const Base_url = 'https://localhost:44303/api/Cart?';

    const params = new HttpParams()
      .set('nombreUser', user)
      .set('factura', factura);

    console.log(Base_url + params.toString());
    
    this.http.post(Base_url + params.toString(), null).subscribe(data => {
      console.log(data);
      if(data == true){
        this.router.navigate(["/basic"]);
        
      }
      this.presentAlert();

      
    });

    

  }

  async presentAlert() {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Compra',
      message: 'Compra realizada con exito.',
      buttons: ['OK']
    });

    await alert.present();
  }
}

