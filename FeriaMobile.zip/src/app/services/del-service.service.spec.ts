import { TestBed } from '@angular/core/testing';

import { DelServiceService } from './del-service.service';

describe('DelServiceService', () => {
  let service: DelServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DelServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

