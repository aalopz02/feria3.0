import { Injectable } from '@angular/core';
import { HttpParams, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  constructor(private http: HttpClient, private router:Router) { }

  addClient(id:string, info: string){

    const Base_url = 'https://localhost:44303/api/Cliente?';

    const params = new HttpParams()
      .set('cedula', id)
      .set('info', info);

    console.log(Base_url + params.toString());
    
    this.http.post(Base_url + params.toString(), null).subscribe(data => {
      console.log(data);
      if(data == true){
        this.router.navigate(["/basic"]);
      }
    });

  }
}
