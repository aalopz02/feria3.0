import { Injectable } from '@angular/core';
import { HttpParams, HttpClient } from '@angular/common/http';
import { Client } from './../models/client.model';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UpServiceService {

  constructor(private http: HttpClient, private router:Router) { }


  updateClient(id:string, info: string){
    const Base_url = 'https://localhost:44303/api/Cliente?';
    

    const params = new HttpParams()
      .set('cedula', id)
      .set('info', info);

    console.log(Base_url + params.toString());
    
    this.http.put(Base_url + params.toString(), null).subscribe(data => {
      console.log(data);
      this.router.navigate(["/basic"]);
    });

  }

  bringClient(user:string): Observable<any>{
    var json;
    console.log("fdsfs");
    const Base_url = 'https://localhost:44303/api/Cliente?';

    const params = new HttpParams()
      .set('user', user);

    console.log(Base_url + params.toString());

    return this.http.get(Base_url + params.toString()).pipe(map((response: any) => response)
    
    );


    
  }

}
  

