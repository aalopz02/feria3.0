import { HttpParams, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

var user="";
@Injectable({
  providedIn: 'root'
})


export class LoginService {
  
  constructor(private http: HttpClient, private router:Router) { }

  CheckLogIn(username: string, password:string){
    const Base_url = 'https://localhost:44303/api/Cliente?';
    
    user=username;
    const params = new HttpParams()
      .set('user', username)
      .set('password', password);

    console.log(Base_url + params.toString());
    
    this.http.get(Base_url + params.toString()).subscribe(data => {
      console.log(data);
      
      if(data == true){
        this.router.navigate(["/basic"]);
      }

    });

  }

  get UserValue() {
    return user;
}
}
