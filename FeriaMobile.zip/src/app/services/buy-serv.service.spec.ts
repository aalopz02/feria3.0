import { TestBed } from '@angular/core/testing';

import { BuyServService } from './buy-serv.service';

describe('BuyServService', () => {
  let service: BuyServService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BuyServService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
