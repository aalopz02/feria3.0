import { Injectable } from '@angular/core';
import { HttpParams, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

var producer_name="";
var producer_lname1="";
var producer_lname2="";
var producer_id="";

@Injectable({
  providedIn: 'root'
})
export class ProducersServService {
  

  constructor(private http: HttpClient, private router:Router) { }


  bringProducers(user:string): Observable<any>{
    
    const Base_url = 'https://localhost:44303/api/Cliente?';

    const params = new HttpParams()
      .set('usuario', user);

    console.log(Base_url + params.toString());

    return this.http.get(Base_url + params.toString()).pipe(map((response: any) => response)
    
    );
}


setProducers(id:string, name:string, lname1: string, lname2: string){
  producer_id=id;
  producer_name=name;
 producer_lname1=lname1;
 producer_lname2=lname2;
   console.log(id);
   console.log(name);
   
   this.router.navigate(["/products"]);
 
 
 }
 
 getProducerId(){
   return producer_id;
 }
 
 getProducerName(){
   return producer_name;
 }
 
 getProducerLName1(){
   return producer_lname1;
 }
 
 getProducerLName2(){
   return producer_lname2;
 }
}
