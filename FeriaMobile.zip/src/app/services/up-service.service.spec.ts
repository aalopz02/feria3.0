import { TestBed } from '@angular/core/testing';

import { UpServiceService } from './up-service.service';

describe('UpServiceService', () => {
  let service: UpServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UpServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
