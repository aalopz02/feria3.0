import { TestBed } from '@angular/core/testing';

import { ProducersServService } from './producers-serv.service';

describe('ProducersServService', () => {
  let service: ProducersServService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProducersServService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
