export class Client {
  id: string;
  name: string;
  lastname: string;
  lastname2: string;
  adress: string;
  birth: string;
  phone_num: string;
  username: string;
  password: string;


  constructor(id: string, name: string, lastname: string, lastname2: string, adress: string, birth: string, phone_num: string, username: string, password: string){
    this.id = id;
    this.name = name;
    this.lastname = lastname;
    this.lastname2 = lastname2
    this.adress = adress;
    this.birth = birth;
    this.phone_num = phone_num;
    this.username = username;
    this.password = password;
  }

}
