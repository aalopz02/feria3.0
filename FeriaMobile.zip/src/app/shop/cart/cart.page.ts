import { Component, OnInit } from '@angular/core';
import { CartServService } from './../../services/cart-serv.service';
import { Router } from '@angular/router';
import { LoginService } from './../../services/login.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.page.html',
  styleUrls: ['./cart.page.css'],
})
export class CartPage implements OnInit {
  public cartlist=[];
  constructor(private cartserv:CartServService,private login:LoginService, private router:Router) { }

  ngOnInit() {

    this.cartserv.bringCart(this.login.UserValue).subscribe(data =>{
      this.cartlist=data;
      console.log(this.cartlist[0]);

    }
    )
  }

  deleteC(producto:string,cedulaProductor:string){
    console.log(this.login.UserValue);
    
    this.cartserv.deleteCart(this.login.UserValue,producto,cedulaProductor);

    this.router.navigate(["/producers"]);
   

  }

  comprar(){
    let r = Math.random().toString(36).substring(7);
    this.cartserv.buy(this.login.UserValue,r);
  }



}
