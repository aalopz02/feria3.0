import { Component, OnInit } from '@angular/core';
import { ProducersServService } from './../../services/producers-serv.service';
import { LoginService } from './../../services/login.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-producers',
  templateUrl: './producers.page.html',
  styleUrls: ['./producers.page.css'],
})
export class ProducersPage implements OnInit {
  public producerlist=[];
  constructor(private serv:ProducersServService,private login:LoginService, private router:Router) { 
   
    
  }

  ngOnInit() {
    this.serv.bringProducers(this.login.UserValue).subscribe(data =>{
      this.producerlist=data;
      console.log(this.producerlist[0]);
      console.log(this.producerlist[1]);
      console.log(this.producerlist[0].nombre);
    }

    )


}

goToProducts(id:string, name:string, lname1: string, lname2: string){
  console.log("hola");
  console.log(name);
  this.serv.setProducers(id,name,lname1,lname2);
}


}