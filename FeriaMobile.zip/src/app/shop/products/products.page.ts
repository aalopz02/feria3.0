import { Component, OnInit } from '@angular/core';
import { ProducersServService } from './../../services/producers-serv.service';

import { ProductsServService } from './../../services/products-serv.service';


import { Router } from '@angular/router';
import { CartServService } from './../../services/cart-serv.service';

import { LoginService } from './../../services/login.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.page.html',
  styleUrls: ['./products.page.css'],
})
export class ProductsPage implements OnInit {

  public cntd;
  public productlist=[];
  public producer_name="";
  public producer_id="";
  public producer_lname1="";
  public producer_lname2="";
  constructor(private producerserv:ProducersServService, private produserv:ProductsServService, private router:Router, private cartserv:CartServService, private login:LoginService) { }

  ngOnInit() {
    this.producer_id=this.producerserv.getProducerId();
    this.producer_name=this.producerserv.getProducerName();
    this.producer_lname1=this.producerserv.getProducerLName1();
    this.producer_lname2=this.producerserv.getProducerLName2();


    this.produserv.bringProducts(this.producer_id).subscribe(data =>{
      this.productlist=data;
      console.log(this.productlist[0]);
      //console.log(this.productlist[1]);
      //console.log(this.productlist[0].nombre);
    }
    )
   
    
  }

  comprar(name:string,cntd:string){
    console.log(name);
    

    this.cartserv.addToCart(this.login.UserValue ,name,cntd,this.producer_id);

    this.router.navigate(["/producers"]);
 
  }

}
